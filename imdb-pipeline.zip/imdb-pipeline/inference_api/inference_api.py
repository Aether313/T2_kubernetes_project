from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd
import tensorflow as tf
import os
import pickle
import numpy as np

app = FastAPI()

DATA_ROOT = os.environ.get("DATA_ROOT", "/data")
MODEL_PATH = os.path.join(DATA_ROOT, "models", "model.h5")
PREPROC_PATH = os.path.join(DATA_ROOT, "models", "preproc.pkl")

model = None
preproc = None

def load_model():
    global model
    if model is None:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(f"Model not found at {MODEL_PATH}")
        model = tf.keras.models.load_model(MODEL_PATH)
    return model

def load_preproc():
    global preproc
    if preproc is None:
        if not os.path.exists(PREPROC_PATH):
            raise FileNotFoundError(f"Preprocessor not found at {PREPROC_PATH}")
        with open(PREPROC_PATH, "rb") as f:
            preproc = pickle.load(f)
    return preproc

def preprocess_input(df, preproc):
    director_map = preproc["director_map"]
    writer_map = preproc["writer_map"]
    prod_map = preproc["prod_map"]
    genre_map = preproc["genre_map"]
    lang_map = preproc["lang_map"]
    tags_map = preproc["tags_map"]
    country_map = preproc["country_map"]
    num_cols = preproc["num_cols"]

    X_num = df[num_cols].astype(float).values
    mean = np.array(preproc["scaler_mean"])
    scale = np.array(preproc["scaler_scale"])
    X_num = (X_num - mean) / scale

    def map_value(val, mapping):
        return mapping.get(val, 0)

    X_cat = []
    if "Director" in df.columns:
        X_cat.append(df["Director"].map(lambda x: map_value(x, director_map)).values)
    if "Writer" in df.columns:
        X_cat.append(df["Writer"].map(lambda x: map_value(x, writer_map)).values)
    if "Production House" in df.columns:
        X_cat.append(df["Production House"].map(lambda x: map_value(x, prod_map)).values)
    if "Genre" in df.columns:
        X_cat.append(df["Genre"].map(lambda x: map_value(x, genre_map)).values)
    if "Language" in df.columns:
        X_cat.append(df["Language"].map(lambda x: map_value(x, lang_map)).values)
    if "Tags" in df.columns:
        X_cat.append(df["Tags"].map(lambda x: map_value(x, tags_map)).values)
    if "Country" in df.columns:
        X_cat.append(df["Country"].map(lambda x: map_value(x, country_map)).values)

    if X_cat:
        X_cat = np.vstack(X_cat).T
        X = np.hstack([X_num, X_cat])
    else:
        X = X_num

    return X

class PredictRequest(BaseModel):
    data: dict

@app.post("/predict")
def predict(request: PredictRequest):
    try:
        mdl = load_model()
        preproc = load_preproc()

        df = pd.DataFrame([request.data])
        X = preprocess_input(df, preproc)

        preds = mdl.predict(X)
        prediction = preds.tolist()

        return {"prediction": prediction}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/healthz")
def healthz():
    return {"status": "ok"}
