from flask import Flask, render_template, request
import requests
import os

app = Flask(__name__)

# Backend service URLs, fetched from environment variables if available
INFERENCE_URL = os.getenv("INFERENCE_URL", "http://inference-svc/predict")
TRAIN_URL = os.getenv("TRAIN_URL", "http://training-svc/train")

# ---------------------------------
# Home page -> Prediction page
# ---------------------------------
@app.route('/')
def predict_page():
    return render_template('predict.html')

# ---------------------------------
# Prediction endpoint
# ---------------------------------
@app.route('/predict', methods=['POST'])
def predict():
    # Collect form data
    runtime_str = request.form.get("Runtime (minutes)", "")

    try:
        runtime_val = int(runtime_str)
    except ValueError:
        runtime_val = None 

    payload = {
        "data": {
            "Genre": request.form.get("Genre", ""),
            "Runtime (minutes)": runtime_val,
            "Language": request.form.get("Language", ""),
            "Director": request.form.get("Director", ""),
            "Writer": request.form.get("Writer", ""),
            "Production House": request.form.get("Production House", "")
        }
    }

    try:
        resp = requests.post(INFERENCE_URL, json=payload)
        if resp.status_code == 200:
            result = resp.json().get("prediction", "No result")
            prediction = f"Predicted IMDB Score: {result}"
        else:
            prediction = f"Error from inference service: {resp.text}"
    except Exception as e:
        prediction = f"Request failed: {str(e)}"

    # Render prediction result on predict.html
    return render_template("predict.html", prediction=prediction)

# ---------------------------------
# Training page
# ---------------------------------
@app.route('/train_page')
def train_page():
    return render_template("train.html")

# ---------------------------------
# Training endpoint (upload dataset)
# ---------------------------------
@app.route('/train', methods=['POST'])
def train():
    file = request.files.get("file")
    if not file:
        return render_template("train.html", accuracy={"status": "error", "msg": "No file uploaded"})

    try:
        # Send uploaded file to training service
        resp = requests.post(TRAIN_URL, files={"file": file})
        if resp.status_code == 200:
            accuracy = resp.json()
        else:
            accuracy = {"status": "error", "msg": resp.text}
    except Exception as e:
        accuracy = {"status": "error", "msg": str(e)}

    # Render training result on train.html
    return render_template("train.html", accuracy=accuracy)

# ---------------------------------
# Launch the app
# ---------------------------------
if __name__ == '__main__':
    # Run on port 8001 inside container
    app.run(host="0.0.0.0", port=8001, debug=True)
